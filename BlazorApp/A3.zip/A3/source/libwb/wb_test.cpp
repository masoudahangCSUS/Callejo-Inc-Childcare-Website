#define CATCH_CONFIG_MAIN

#include "wb.h"
#include "vendor/catch.hpp"
